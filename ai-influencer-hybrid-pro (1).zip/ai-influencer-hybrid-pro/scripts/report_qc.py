#!/usr/bin/env python3
import os, csv, argparse, base64
from pathlib import Path

TEMPLATE = r"""<!doctype html>
<html><head>
<meta charset="utf-8">
<title>QC Report</title>
<style>
body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;margin:24px;background:#111;color:#eee}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px}
.card{background:#1b1b1b;border:1px solid #2a2a2a;border-radius:12px;padding:10px}
.card img{width:100%;height:auto;border-radius:8px;display:block}
.meta{font-size:12px;opacity:.85;margin-top:6px}
.pass{color:#7CFC00}.fail{color:#ff6b6b}
table{width:100%;border-collapse:collapse;margin:12px 0}
th,td{border-bottom:1px solid #2a2a2a;padding:6px 8px;text-align:left}
</style></head><body>
<h1>QC Report</h1>
<p>Directory: {dir}</p>
<table><thead><tr><th>Filename</th><th>cos_sim</th><th>blur</th><th>pass</th></tr></thead><tbody>
{rows}
</tbody></table>
<div class="grid">
{cards}
</div>
</body></html>
"""

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--qc_dir", required=True, help="directory with qc_report.csv and images")
    ap.add_argument("--out", default="qc_report.html")
    ap.add_argument("--limit", type=int, default=120)
    args = ap.parse_args()

    report_csv = Path(args.qc_dir) / "qc_report.csv"
    rows_html = []
    cards_html = []
    images = []
    if report_csv.exists():
        with report_csv.open("r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for r in reader:
                rows_html.append(f"<tr><td>{r['filename']}</td><td>{r['cos_sim']}</td><td>{r['blur']}</td><td class={'pass' if r['pass']=='1' else 'fail'}>{r['pass']}</td></tr>")
                if r['pass']=='1':
                    images.append(r['filename'])
    for fn in images[:args.limit]:
        img_path = Path(args.qc_dir) / fn
        if not img_path.exists(): 
            continue
        b64 = base64.b64encode(img_path.read_bytes()).decode("ascii")
        cards_html.append(f"<div class='card'><img src='data:image/jpeg;base64,{b64}'/><div class='meta'>{fn}</div></div>")

    html = TEMPLATE.format(dir=args.qc_dir, rows="\n".join(rows_html), cards="\n".join(cards_html))
    Path(args.out).write_text(html, encoding="utf-8")
    print(f"[DONE] Wrote {args.out}")

if __name__ == "__main__":
    main()
