# InfluencerAI – Validator Kit (v1)

Questo kit fornisce:
- `validator.py`: CLI per validare sidecar/manifest, rilevare near-duplicate (pHash/SSIM), produrre report.
- `requirements.txt`: dipendenze minime (no download di pesi modelli).
- `n8n_workflow_folder_watcher.json`: workflow base per watcher di cartelle e report giornaliero.

**Nota importante**: la similarità facciale vera basata su embedding (InsightFace/FaceNet) non è inclusa qui. Il validator offre una modalità **proxy** usando pHash come surrogato (`--face-sim-mode phash`). Per produzione, integra un hook esterno (`--external-face-sim module:function`) che ritorni un valore [0..1].

## Installazione
```bash
python -m venv .venv
. .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Esempio d'uso
```bash
python validator.py   --dataset-root D:/datasets/influencer_ai/avatar01   --schema-sidecar D:/kits/influencerai_dataset_kit_v1/sidecar_schema.json   --schema-manifest D:/kits/influencerai_dataset_kit_v1/manifest_schema.json   --manifest D:/datasets/influencer_ai/avatar01/dataset_manifest.json   --report-dir D:/datasets/influencer_ai/avatar01/reports   --face-sim-mode phash   --phash-th 10   --ssim-th 0.985
```

## Exit codes
- `0`: tutto ok
- `1`: solo warning (es. sidecar mancanti, near-dup sospetti)
- `2`: errori (es. failure lettura file, eccezioni non gestite)

## Integrazione face-sim esterna (embedding reale)
Scrivi un modulo Python, ad es. `facesim_hook.py`, con:
```python
def similarity(image_path: str) -> float:
    """Ritorna similarità [0..1] rispetto all'embedding prototipo (devi gestire tu il caricamento modello)."""
    # TODO: implement
    return 0.0
```
Poi avvia:
```bash
python validator.py ... --face-sim-mode external --external-face-sim facesim_hook:similarity
```

## Politica split
Questo kit non riscrive lo split, ma puoi leggere `validation_report.json` e aggiornare `dataset_manifest.json` nel tuo pipeline (n8n).

## Limiti e raccomandazioni
- SSIM implementata in versione semplificata (monocanale, finestra globale). Usala come **segnalatore**, non come verità assoluta.
- pHash/SSIM sono insiemi di indizi: per decisioni finali, mantieni revisione umana su coppie con soglie borderline.
- Evita augmentation aggressiva (>×2) nella stessa condizione di luce/contesto.
