#!/usr/bin/env python3
"""
InfluencerAI Dataset Validator (v1)
- Validates sidecar and manifest JSON against provided JSON Schemas
- Computes pHash and SSIM for dedup/near-dup checks
- Optional "face similarity" placeholder (uses pHash distance as proxy unless external hook is provided)
- Produces a validation report (JSON + Markdown)

Usage:
  python validator.py \
    --dataset-root /path/to/dataset \
    --schema-sidecar /path/to/sidecar_schema.json \
    --schema-manifest /path/to/manifest_schema.json \
    --report-dir ./reports \
    --split-policy stratified \
    --face-sim-mode phash \
    --face-sim-threshold 0.85 \
    --phash-th 10 \
    --ssim-th 0.98

Notes:
- "face similarity" true embeddings require external tools; this script provides a proxy mode.
- You can plug your own face-sim function via --external-face-sim module:function (see README).
"""
import os, sys, json, argparse, hashlib, importlib
from pathlib import Path
from typing import List, Dict, Any, Tuple
from PIL import Image, ImageOps
import numpy as np

# Optional: jsonschema validation
try:
    import jsonschema
    HAS_JSONSCHEMA = True
except ImportError:
    HAS_JSONSCHEMA = False

def load_json(p: Path) -> Dict[str, Any]:
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(p: Path, obj: Any):
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def avg_hash(img: Image.Image, hash_size: int = 8) -> np.ndarray:
    # aHash (average hash) as quick baseline
    img = ImageOps.exif_transpose(img)
    img = img.convert("L").resize((hash_size, hash_size), Image.BILINEAR)
    pixels = np.array(img, dtype=np.float32)
    return (pixels > pixels.mean()).astype(np.uint8)

def dct2(a):
    return np.fft.fft2(a)

def p_hash(img: Image.Image, hash_size: int = 8, highfreq_factor: int = 4) -> np.ndarray:
    # Perceptual hash based on DCT
    img = ImageOps.exif_transpose(img)
    img = img.convert("L").resize((hash_size*highfreq_factor, hash_size*highfreq_factor), Image.BILINEAR)
    a = np.array(img, dtype=np.float32)
    dct = np.real(np.fft.fft2(a))
    dctlowfreq = dct[:hash_size, :hash_size]
    med = np.median(dctlowfreq)
    return (dctlowfreq > med).astype(np.uint8)

def hamming(a: np.ndarray, b: np.ndarray) -> int:
    return int(np.sum(a.flatten() != b.flatten()))

def ssim(imgA: Image.Image, imgB: Image.Image) -> float:
    # Simple SSIM implementation (luma only), windowless rough variant
    # Warning: this is a rough approximation for near-dup detection.
    a = np.array(ImageOps.exif_transpose(imgA).convert("L"), dtype=np.float32) / 255.0
    b = np.array(ImageOps.exif_transpose(imgB).convert("L"), dtype=np.float32) / 255.0
    muA, muB = a.mean(), b.mean()
    sigmaA, sigmaB = a.std(), b.std()
    sigmaAB = ((a - muA) * (b - muB)).mean()
    C1 = 0.01 ** 2
    C2 = 0.03 ** 2
    num = (2 * muA * muB + C1) * (2 * sigmaAB + C2)
    den = (muA ** 2 + muB ** 2 + C1) * (sigmaA ** 2 + sigmaB ** 2 + C2)
    return float(num / den) if den != 0 else 0.0

def validate_json(obj: Dict[str, Any], schema: Dict[str, Any]) -> List[str]:
    if not HAS_JSONSCHEMA:
        return ["jsonschema not installed; skipped formal schema validation"]
    try:
        jsonschema.validate(instance=obj, schema=schema)
        return []
    except jsonschema.exceptions.ValidationError as e:
        return [f"Schema validation error: {e.message} at {'/'.join(map(str, e.path))}"]

def compute_phash_for_file(fp: Path) -> np.ndarray:
    with Image.open(fp) as im:
        return p_hash(im)

def compute_ssim_for_pair(a: Path, b: Path) -> float:
    with Image.open(a) as ia, Image.open(b) as ib:
        return ssim(ia, ib)

def discover_images(dataset_root: Path) -> List[Path]:
    exts = {".png", ".jpg", ".jpeg", ".webp"}
    files = []
    for p in dataset_root.rglob("*"):
        if p.suffix.lower() in exts:
            files.append(p)
    return files

def default_sidecar_for(img_path: Path) -> Path:
    # assumes same basename with .json
    return img_path.with_suffix(".json")

def load_external_face_sim(hook: str):
    # hook format: module:function
    if not hook or ":" not in hook:
        return None
    mod_name, fn_name = hook.split(":", 1)
    mod = importlib.import_module(mod_name)
    return getattr(mod, fn_name)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset-root", required=True, help="Root folder containing images and sidecars")
    ap.add_argument("--schema-sidecar", required=True, help="Path to sidecar_schema.json")
    ap.add_argument("--schema-manifest", required=True, help="Path to manifest_schema.json")
    ap.add_argument("--manifest", default="", help="Optional path to dataset_manifest.json (if exists)")
    ap.add_argument("--report-dir", default="./reports", help="Where to write reports")
    ap.add_argument("--face-sim-mode", choices=["none","phash","external"], default="phash")
    ap.add_argument("--external-face-sim", default="", help="module:function to compute face similarity [0..1]")
    ap.add_argument("--face-sim-threshold", type=float, default=0.85)
    ap.add_argument("--phash-th", type=int, default=10, help="Hamming distance threshold for near-dup reject")
    ap.add_argument("--ssim-th", type=float, default=0.985, help="SSIM threshold above which images are near-dups")
    args = ap.parse_args()

    root = Path(args.dataset_root)
    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)

    schema_sidecar = load_json(Path(args.schema_sidecar))
    schema_manifest = load_json(Path(args.schema_manifest))

    manifest_path = Path(args.manifest) if args.manifest else None
    manifest = load_json(manifest_path) if manifest_path and manifest_path.exists() else {"items": []}

    # External face-sim hook
    face_sim_fn = None
    if args.face-sim-mode == "external":
        face_sim_fn = load_external_face_sim(args.external_face_sim)
        if face_sim_fn is None:
            print("ERROR: external face-sim hook not found; falling back to 'phash' mode", file=sys.stderr)
            args.face_sim_mode = "phash"

    images = discover_images(root)
    # compute hashes
    phashes = {}
    errors = []
    warnings = []

    # Validate sidecars
    results = []
    for img in images:
        item = {"file": str(img.relative_to(root)), "checks": {}}
        # Sidecar
        sidecar_path = default_sidecar_for(img)
        if sidecar_path.exists():
            sidecar = load_json(sidecar_path)
            err = validate_json(sidecar, schema_sidecar)
            item["checks"]["sidecar_schema"] = "ok" if not err else "fail"
            if err:
                item["checks"]["sidecar_errors"] = err
        else:
            item["checks"]["sidecar_schema"] = "missing"
            warnings.append(f"Missing sidecar for {img}")

        # pHash
        try:
            ph = compute_phash_for_file(img)
            phashes[img] = ph
            item["checks"]["phash"] = "ok"
        except Exception as e:
            item["checks"]["phash"] = f"error: {e}"
            errors.append(f"pHash error for {img}: {e}")

        results.append(item)

    # Near-dup detection (pairwise)
    # For scalability, use a simple LSH: bucket by quick avg_hash string
    buckets = {}
    for img in images:
        try:
            with Image.open(img) as im:
                ah = avg_hash(im)
                key = ''.join(map(str, ah.flatten().tolist()))
        except Exception:
            key = "err"
        buckets.setdefault(key, []).append(img)

    near_dups = []
    for key, group in buckets.items():
        if len(group) < 2:
            continue
        # compare within bucket
        for i in range(len(group)):
            for j in range(i+1, len(group)):
                a, b = group[i], group[j]
                try:
                    h = hamming(phashes[a], phashes[b])
                    s = compute_ssim_for_pair(a, b)
                    if h <= args.phash_th or s >= args.ssim_th:
                        near_dups.append({
                            "a": str(a.relative_to(root)),
                            "b": str(b.relative_to(root)),
                            "hamming": int(h),
                            "ssim": float(s)
                        })
                except Exception as e:
                    warnings.append(f"Pair check failed for {a} vs {b}: {e}")

    # Manifest validation if present
    manifest_errors = []
    if manifest.get("items"):
        m_err = validate_json(manifest, schema_manifest)
        if m_err:
            manifest_errors.extend(m_err)

    report = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "dataset_root": str(root),
        "images_count": len(images),
        "near_duplicates": near_dups,
        "items": results,
        "warnings": warnings,
        "errors": errors,
        "manifest_validation": "ok" if not manifest_errors else "fail",
        "manifest_errors": manifest_errors
    }
    save_json(report_dir / "validation_report.json", report)

    # Markdown summary
    md = ["# InfluencerAI Dataset – Validation Report",
          f"- Generated at: {report['generated_at']}",
          f"- Images scanned: {report['images_count']}",
          f"- Near-duplicates detected: {len(near_dups)}",
          f"- Warnings: {len(warnings)}",
          f"- Errors: {len(errors)}",
          "",
          "## Near-duplicates (sample up to 50)"]
    for pair in near_dups[:50]:
        md.append(f"- `{pair['a']}` ↔ `{pair['b']}` | Hamming={pair['hamming']} | SSIM={pair['ssim']:.4f}")
    md.append("\n## Warnings")
    for w in warnings[:50]:
        md.append(f"- {w}")
    md.append("\n## Errors")
    for e in errors[:50]:
        md.append(f"- {e}")
    (report_dir / "validation_report.md").write_text("\n".join(md), encoding="utf-8")

    print(f"Report written to: {report_dir}")
    if errors:
        sys.exit(2)
    elif warnings:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == "__main__":
    main()
